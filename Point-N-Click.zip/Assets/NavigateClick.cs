using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NavigateClick : MonoBehaviour
{
    UnityEngine.AI.NavMeshAgent _meshAgent;
    void Start()
    {
        _meshAgent = GetComponent<UnityEngine.AI.NavMeshAgent>();
        transform.position = new Vector3(0f, 0.5f, 0f);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButton(0))
        {
            CalculaDestino();
        }
    }
    void CalculaDestino()
    {
        RaycastHit lHit;
        Ray lRay = Camera.main.ScreenPointToRay(Input.mousePosition);
        if (Physics.Raycast(lRay, out lHit))
        {
            _meshAgent.SetDestination(lHit.point);
        }
    }
}
